"""Experiment 5 - packet counts of the exported .pcap files per display filter.

Usage:  python pcap_report.py results/AodvCapture [host_index]

Prints, for one host's capture (default host0):
  * packets matching udp / icmp / aodv (and mip6 if present)
  * conversations and a 10-second I/O summary
and compares the number of UDP data packets seen with the scalar results of
the simulation (packetSent:count / packetReceived:count in run.sca).
Needs tshark on the PATH.
"""
import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
from omnet_results import parse_sca

FILTERS = ["udp", "icmp", "aodv", "mip6", "udp.port==5000"]


def count(pcap, flt):
    out = subprocess.run(["tshark", "-r", pcap, "-Y", flt, "-T", "fields", "-e", "frame.number"],
                         capture_output=True, text=True).stdout
    return len([l for l in out.splitlines() if l.strip()])


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    rdir = sys.argv[1]
    host = sys.argv[2] if len(sys.argv) > 2 else "0"
    pcap = os.path.join(rdir, "host%s.pcap" % host)
    if not shutil.which("tshark"):
        sys.exit("tshark not found - install Wireshark and add it to PATH.")
    if not os.path.exists(pcap):
        sys.exit("%s not found - run the simulation first." % pcap)

    print("\nCapture: %s" % pcap)
    print("%-18s %s" % ("Display filter", "Packets"))
    for f in FILTERS:
        print("%-18s %d" % (f, count(pcap, f)))

    for z in ("conv,ip", "io,stat,10"):
        print("\n$ tshark -r %s -q -z %s" % (pcap, z))
        print(subprocess.run(["tshark", "-r", pcap, "-q", "-z", z], capture_output=True, text=True).stdout)

    sca = os.path.join(rdir, "run.sca")
    if os.path.exists(sca):
        r = parse_sca(sca)
        sent = sum(v for m, n, v in r["scalars"] if n == "packetSent:count" and ".host[0].app[0]" in m)
        recv = sum(v for m, n, v in r["scalars"] if n == "packetReceived:count" and ".host[9].app[0]" in m)
        print("Simulator scalars: UDP sent by host[0] = %d, received by host[9] = %d" % (sent, recv))
        print("Compare with the pcap counts: a packet is captured once per transmission "
              "and once per reception, forwarded packets appear at every hop, and lost or "
              "retransmitted frames also change the totals - explain the difference.")


if __name__ == "__main__":
    main()
