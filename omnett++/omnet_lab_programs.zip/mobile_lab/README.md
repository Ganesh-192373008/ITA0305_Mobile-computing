# Mobile Computing and Communication Lab - OMNeT++ programs (6 experiments)

Ready-made configuration and analysis files for the six experiments of the lab manual.

| Exp | Folder | What you run | Needs |
|---|---|---|---|
| 1 | `exp1_handover` | config **Handover** (60 s, 5 seeds, 1/10/30 m/s) then `analyze_handover.py` | OMNeT++, INET, Simu5G, Python |
| 2 | `exp2_wireshark` | `analyze_capture.py gsm/gtp/s1ap/ngap <capture>` | Wireshark/tshark, sample captures |
| 3 | `exp3_mobileipv6` | INET example *mipv6roaming* + `pcap_addon.ini`, then `analyze_mipv6.py` | OMNeT++, INET, tshark |
| 4 | `exp4_adhoc` | configs **AODV** and **DSDV** (200 s, 2/10/20 m/s, 5 seeds) then `analyze_adhoc.py` | OMNeT++, INET, Python (+tshark for overhead) |
| 5 | `exp5_pcap` | config **AodvCapture** / **DsdvCapture** then `pcap_report.py` | OMNeT++, INET, tshark |
| 6 | `exp6_miniproject` | config **NumUes** (1-30 UEs, 5 seeds) then `analyze_mini_project.py` | OMNeT++, INET, Simu5G, Python |

## Setting up in the OMNeT++ IDE
1. Experiments 1 and 6: copy the `exp1_handover` / `exp6_miniproject` folders into your
   **Simu5G** project (for example under `simulations/nr/`). Both `inet` and `simu5g` are then
   on the NED path automatically.
2. Experiments 4 and 5: create *File > New > OMNeT++ Project > Empty project*, tick **INET** in
   *Project > Properties > Project References*, and copy in `AdhocNetworks.ned` (project root),
   `exp4_adhoc`, `exp5_pcap` and `tools`.
3. Open an `omnetpp.ini`, choose the configuration (see table), and run it (Qtenv to watch it,
   Cmdenv for the batch of repetitions). Results are written to `results/<config>/`.
4. Run the Python script next to the ini from the project folder, e.g.
   `python exp4_adhoc/analyze_adhoc.py results`  (needs `pip install pandas matplotlib numpy`).
5. Copy the printed tables and the saved PNG graphs into the Output sections of the manual.

## What was and was not checked
- Module, parameter and network names were checked against the **current INET and Simu5G
  source code** (GitHub master as of 24 Nov 2026): `AodvRouter`, `DsdvRouter`,
  `MultiCell_Standalone`, `SingleCell_Standalone`, `CbrSender/CbrReceiver`,
  `PcapRecorder`, and the `mipv6roaming` example.
- The result parsers and analysis scripts were tested on synthetic result files.
- **The simulations themselves were NOT run** (OMNeT++ is not available where this was prepared),
  and the tshark steps were not run either. If your lab uses an older INET / Simu5G, a parameter
  name may differ (the manual warns about this) - check the error message and compare with the
  example project of your version. In particular, the 5G handover time in Exp 1 is estimated as
  the start of the largest reception gap, and Exp 4's routing overhead counts every transmitted
  non-data IP frame (needs the pcap lines in `exp4_adhoc/omnetpp.ini` and tshark).
- Run times: Exp 4 is 2 protocols x 3 speeds x 5 seeds = 30 runs of 200 s; remove the pcap lines
  in its ini if you only need PDR and delay.
