"""Experiment 1 - post-processing.

Reads the .vec files written by the Handover config, and for every speed:
  * rebuilds the packet arrival times at the UE (cbrReceivedBytes vector)
  * interruption (ms)  = largest gap between two consecutive packets
  * handover time (s)  = instant at which that gap starts
  * mean throughput    = received bits / reception time
and plots throughput against time with the handover instant marked.

Usage:  python analyze_handover.py [results_dir]      (default: results/Handover)
"""
import glob
import os
import sys
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
from omnet_results import parse_vec

GAP_THRESHOLD_S = 0.05      # a gap longer than 50 ms counts as a handover interruption


def interruption_ms(rx_times):
    gaps = [b - a for a, b in zip(rx_times, rx_times[1:])]
    return 1000.0 * max(gaps)


def analyse(vec_path):
    res = parse_vec(vec_path)
    key = [k for k in res["vectors"] if k[1].startswith("cbrReceivedBytes") and ".ue[0]" in k[0]]
    if not key:
        return None
    t, size = res["vectors"][key[0]]
    t, size = np.array(t), np.array(size)
    if len(t) < 2:
        return None
    gaps = np.diff(t)
    i = int(np.argmax(gaps))
    ho_time = t[i] if gaps[i] > GAP_THRESHOLD_S else float("nan")
    return {
        "speed": int(float(res["itervars"].get("speed", "0"))),
        "t": t, "size": size,
        "interruption_ms": interruption_ms(t),
        "handover_time": ho_time,
        "throughput_mbps": size.sum() * 8 / (t[-1] - t[0]) / 1e6,
    }


def main():
    rdir = sys.argv[1] if len(sys.argv) > 1 else os.path.join("results", "Handover")
    files = sorted(glob.glob(os.path.join(rdir, "*.vec")))
    if not files:
        sys.exit("No .vec files in %s - run the Handover config first." % rdir)

    per_speed = defaultdict(list)
    for f in files:
        r = analyse(f)
        if r:
            per_speed[r["speed"]].append(r)

    print("\nSpeed (m/s) | Handover time (s) | Interruption (ms) | Mean throughput (Mbps)")
    print("-" * 75)
    rows = []
    for sp in sorted(per_speed):
        runs = per_speed[sp]
        ho = np.nanmean([r["handover_time"] for r in runs])
        it = np.mean([r["interruption_ms"] for r in runs])
        th = np.mean([r["throughput_mbps"] for r in runs])
        rows.append((sp, ho, it, th))
        print("%11d | %17.2f | %17.1f | %22.3f" % (sp, ho, it, th))
    with open("exp1_summary.csv", "w") as fh:
        fh.write("speed_mps,handover_time_s,interruption_ms,mean_throughput_mbps\n")
        for r in rows:
            fh.write("%d,%.3f,%.2f,%.4f\n" % r)

    fig, axes = plt.subplots(len(per_speed), 1, figsize=(8, 3 * len(per_speed)), sharex=True)
    axes = np.atleast_1d(axes)
    for ax, sp in zip(axes, sorted(per_speed)):
        r = per_speed[sp][0]                              # first repetition
        edges = np.arange(0, 61, 1.0)
        mbps, _ = np.histogram(r["t"], bins=edges, weights=r["size"] * 8 / 1e6)
        ax.plot(edges[:-1] + 0.5, mbps, marker="o", ms=3)
        if not np.isnan(r["handover_time"]):
            ax.axvline(r["handover_time"], color="red", ls="--", label="handover")
            ax.legend()
        ax.set_ylabel("Throughput (Mbps)")
        ax.set_title("UE speed %d m/s" % sp)
        ax.grid(True)
    axes[-1].set_xlabel("Time (s)")
    fig.tight_layout()
    fig.savefig("exp1_throughput.png", dpi=150)
    print("\nSaved exp1_summary.csv and exp1_throughput.png")


if __name__ == "__main__":
    main()
