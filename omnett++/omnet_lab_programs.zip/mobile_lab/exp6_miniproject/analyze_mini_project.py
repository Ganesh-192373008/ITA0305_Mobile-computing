"""Experiment 6 - mean and 95 % confidence interval of repeated runs.

1. Reads every .sca file of results/NumUes and writes results.csv with the
   columns of the manual:  config, param, run, throughput, delay
       param      = number of UEs
       throughput = total cell downlink throughput of the run (Mbps)
       delay      = mean packet delay over all UEs of the run (ms)
2. Plots mean +/- 95 % CI (1.96 * s / sqrt(n)) for throughput and for delay
   -> mini_project.png (throughput) and mini_project_delay.png (delay).
Usage:  python analyze_mini_project.py [results_dir]     (default results/NumUes)
"""
import glob
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
from omnet_results import parse_sca


def build_csv(rdir):
    rows = []
    for run, f in enumerate(sorted(glob.glob(os.path.join(rdir, "*.sca")))):
        r = parse_sca(f)
        thr = [v for m, n, v in r["scalars"] if n.startswith("cbrReceivedThroughput") and ".ue[" in m]
        dly = [v for m, n, v in r["scalars"] if n.startswith("cbrFrameDelay") and ".ue[" in m]
        if not thr or not dly:
            continue
        rows.append({
            "config": os.path.basename(rdir),
            "param": int(float(r["itervars"].get("numUEs", len(thr)))),
            "run": run,
            "throughput": sum(thr) * 8 / 1e6,          # Bps -> Mbps, whole cell
            "delay": 1000.0 * float(np.mean(dly)),     # s -> ms
        })
    if not rows:
        sys.exit("No usable .sca files in %s - run the NumUes config first." % rdir)
    pd.DataFrame(rows).to_csv("results.csv", index=False)


def plot(df, col, ylabel, out):
    g = df.groupby("param")[col]
    mean, ci = g.mean(), 1.96 * g.std() / np.sqrt(g.count())
    plt.figure(figsize=(6, 4))
    plt.errorbar(mean.index, mean.values, yerr=ci.values, marker="o", capsize=3)
    plt.xlabel("Number of UEs")
    plt.ylabel(ylabel)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(out, dpi=150)
    plt.close()


def main():
    rdir = sys.argv[1] if len(sys.argv) > 1 else os.path.join("results", "NumUes")
    build_csv(rdir)
    df = pd.read_csv("results.csv")
    plot(df, "throughput", "Mean cell throughput (Mbps)", "mini_project.png")
    plot(df, "delay", "Mean delay (ms)", "mini_project_delay.png")
    print(df.groupby("param")[["throughput", "delay"]].agg(["mean", "std"]).round(3))
    print("\nSaved results.csv, mini_project.png, mini_project_delay.png")


if __name__ == "__main__":
    main()
