# Experiment 3 - Mobile IP and mobility signalling

Uses the Mobile IPv6 roaming example that ships with INET
(`examples/ipv6/mipv6roaming`): one mobile node, home agent, two foreign
networks, correspondent node pinging the home address.

1. In the OMNeT++ IDE import/open INET, open `examples/ipv6/mipv6roaming`.
2. Run config **Roaming** in Qtenv. Identify Home_Agent, CN[0], MN[0], AP_Home,
   AP_1, AP_2, R_1, R_2_acc. Watch: movement detection -> care-of address ->
   Binding Update -> Binding Acknowledgement (two handovers).
3. Append `pcap_addon.ini` to the example's `omnetpp.ini`, run **RoamingPcap**.
4. Open `results/mn.pcap` in Wireshark with filters `mip6`, `icmpv6`,
   `ipv6.dst == <CoA>`, or run
       python analyze_mipv6.py results/mn.pcap
   and copy the times into the Output table.
