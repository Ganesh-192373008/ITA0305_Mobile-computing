"""Experiment 3 - timeline of the Mobile IPv6 signalling from a .pcap file.

Usage:  python analyze_mipv6.py results/mn.pcap

Prints
  * the Router Solicitation / Advertisement and the mip6 messages (Binding
    Update, Binding Acknowledgement, Home/Care-of Test ...) in time order
  * the ICMPv6 Echo Replies received by the mobile node and the largest gaps
    between them (the correspondent node pings every 0.5 s, so a gap much
    larger than 0.5 s marks packet loss during a handover).
Fill the "Event / Time / Observation" table of the manual from this output.
Needs tshark on the PATH.
"""
import shutil
import subprocess
import sys


def fields(pcap, flt, *fl):
    cmd = ["tshark", "-r", pcap, "-Y", flt, "-T", "fields", "-E", "separator=|"]
    for f in fl:
        cmd += ["-e", f]
    out = subprocess.run(cmd, capture_output=True, text=True).stdout
    return [l.split("|") for l in out.splitlines() if l.strip()]


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    pcap = sys.argv[1]
    if not shutil.which("tshark"):
        sys.exit("tshark not found - install Wireshark and add it to PATH.")

    print("\n--- movement detection / signalling (time s | info) ---")
    rows = fields(pcap, "icmpv6.type==133 || icmpv6.type==134 || mip6",
                  "frame.time_relative", "_ws.col.Info")
    for t, info in rows:
        label = ""
        low = info.lower()
        if "router solicitation" in low:
            label = "movement detected (RS sent after re-association)"
        elif "router advertisement" in low:
            label = "RA received -> care-of address configured"
        elif "binding update" in low:
            label = "Binding Update sent"
        elif "binding acknowledg" in low:
            label = "Binding Acknowledgement received"
        print("%9.3f | %-60s %s" % (float(t), info[:60], ("<- " + label) if label else ""))

    replies = [float(r[0]) for r in fields(pcap, "icmpv6.type==129", "frame.time_relative")]
    print("\nEcho Replies received: %d" % len(replies))
    gaps = sorted(((b - a, a) for a, b in zip(replies, replies[1:])), reverse=True)[:3]
    for g, at in gaps:
        print("  gap %.2f s starting at t = %.2f s  (~%d lost pings)" % (g, at, round(g / 0.5) - 1))


if __name__ == "__main__":
    main()
