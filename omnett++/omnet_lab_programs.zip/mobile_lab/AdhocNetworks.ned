//
// Networks for Experiments 4 and 5 (AODV versus DSDV).
// Both use the same 802.11 radio medium and the same hosts, so that the only
// difference between the two networks is the routing protocol.
//
import inet.networklayer.configurator.ipv4.Ipv4NetworkConfigurator;
import inet.node.aodv.AodvRouter;
import inet.node.dsdv.DsdvRouter;
import inet.physicallayer.wireless.ieee80211.packetlevel.Ieee80211ScalarRadioMedium;

network AodvNetwork
{
    parameters:
        int numHosts = default(15);
        @display("bgb=650,650");
    submodules:
        radioMedium: Ieee80211ScalarRadioMedium {
            @display("p=100,200;is=s");
        }
        configurator: Ipv4NetworkConfigurator {
            config = xml("<config><interface hosts='*' address='145.236.x.x' netmask='255.255.0.0'/></config>");
            @display("p=100,100;is=s");
        }
        host[numHosts]: AodvRouter {
            @display("i=device/pocketpc_s;r=,,#707070");
        }
    connections allowunconnected:
}

network DsdvNetwork
{
    parameters:
        int numHosts = default(15);
        @display("bgb=650,650");
    submodules:
        radioMedium: Ieee80211ScalarRadioMedium {
            @display("p=100,200;is=s");
        }
        configurator: Ipv4NetworkConfigurator {
            config = xml("<config><interface hosts='*' address='145.236.x.x' netmask='255.255.0.0'/></config>");
            @display("p=100,100;is=s");
        }
        host[numHosts]: DsdvRouter {
            dsdv.netmask = "255.255.0.0";
            @display("i=device/pocketpc_s;r=,,#707070");
        }
    connections allowunconnected:
}
