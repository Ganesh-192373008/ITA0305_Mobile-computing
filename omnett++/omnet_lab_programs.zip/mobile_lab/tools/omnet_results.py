"""Tiny readers for OMNeT++ result files (.sca / .vec), no extra tools needed.

parse_sca(path) -> dict(itervars, scalars, stats)
    scalars : list of (module, name, value)
    stats   : {(module, name): {"count":..., "mean":..., ...}}
parse_vec(path) -> dict(itervars, vectors)
    vectors : {(module, name): (times, values)}
"""
import shlex


def _num(x):
    try:
        return float(x)
    except ValueError:
        return x


def parse_sca(path):
    itervars, scalars, stats, cur = {}, [], {}, None
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line:
                continue
            p = shlex.split(line)
            if p[0] == "itervar" and len(p) >= 3:
                itervars[p[1]] = p[2]
            elif p[0] == "scalar" and len(p) >= 4:
                scalars.append((p[1], p[2], _num(p[3])))
            elif p[0] in ("statistic", "histogram") and len(p) >= 3:
                cur = (p[1], p[2])
                stats[cur] = {}
            elif p[0] == "field" and cur is not None and len(p) >= 3:
                stats[cur][p[1]] = _num(p[2])
            elif p[0] not in ("bin", "attr", "field"):
                cur = None
    return {"itervars": itervars, "scalars": scalars, "stats": stats}


def parse_vec(path):
    itervars, decl, data = {}, {}, {}
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            if not line.strip():
                continue
            if line[0].isdigit():
                c = line.split()
                vid = int(c[0])
                if vid not in decl:
                    continue
                cols = decl[vid][2]
                if cols == "ETV" and len(c) >= 4:
                    t, v = float(c[2]), float(c[3])
                elif len(c) >= 3:
                    t, v = float(c[-2]), float(c[-1])
                else:
                    continue
                data[vid][0].append(t)
                data[vid][1].append(v)
                continue
            p = shlex.split(line)
            if p[0] == "itervar" and len(p) >= 3:
                itervars[p[1]] = p[2]
            elif p[0] == "vector" and len(p) >= 4:
                vid = int(p[1])
                cols = p[4] if len(p) > 4 else "ETV"
                decl[vid] = (p[2], p[3], cols)
                data[vid] = ([], [])
    vectors = {(decl[v][0], decl[v][1]): data[v] for v in decl}
    return {"itervars": itervars, "vectors": vectors}
