"""Experiment 2 - tshark helper for the GSM / GTP / S1AP / NGAP sample captures.

Usage examples
    python analyze_capture.py gsm   gsm_sample.pcap
    python analyze_capture.py gtp   gtp_sample.pcap
    python analyze_capture.py s1ap  s1ap_sample.pcap
    python analyze_capture.py ngap  ngap_sample.pcap

For each capture type it prints
   1. the first 20 matching packets (the tshark commands of the manual)
   2. the protocol hierarchy            (tshark -z io,phs)
   3. the IP conversations              (tshark -z conv,ip)
   4. the ordered message list (frame, time, info) of the signalling procedure,
      which is what you copy into the "Key messages (in order)" column.
Needs tshark (installed together with Wireshark) on the PATH.
"""
import shutil
import subprocess
import sys

FILTERS = {
    "gsm": "gsm_a.dtap",
    "gtp": "gtp || gtpv2",
    "s1ap": "s1ap",
    "ngap": "ngap",
}
EXTRA = {
    "gtp": ["-e", "gtp.teid", "-e", "gtpv2.teid"],
}


def run(cmd):
    print("\n$ " + " ".join(cmd))
    out = subprocess.run(cmd, capture_output=True, text=True)
    print(out.stdout if out.stdout.strip() else out.stderr)


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in FILTERS:
        sys.exit(__doc__)
    kind, pcap = sys.argv[1], sys.argv[2]
    if not shutil.which("tshark"):
        sys.exit("tshark not found - install Wireshark and add it to PATH.")
    flt = FILTERS[kind]

    run(["tshark", "-r", pcap, "-Y", flt, "-c", "20"])
    run(["tshark", "-r", pcap, "-q", "-z", "io,phs"])
    run(["tshark", "-r", pcap, "-q", "-z", "conv,ip"])
    print("\n--- ordered messages of the procedure (frame, time, info) ---")
    run(["tshark", "-r", pcap, "-Y", flt, "-T", "fields",
         "-e", "frame.number", "-e", "frame.time_relative", "-e", "_ws.col.Info"] + EXTRA.get(kind, []))
    if kind in ("s1ap", "ngap"):
        print("Tip: Statistics > Flow Graph (Wireshark GUI) draws this as a message sequence chart.")


if __name__ == "__main__":
    main()
