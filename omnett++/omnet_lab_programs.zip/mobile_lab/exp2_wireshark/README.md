# Experiment 2 - Cellular protocol analysis with Wireshark

No simulation is needed here. Steps:

1. Download sample captures from the Wireshark wiki page **SampleCaptures**
   (wiki.wireshark.org/SampleCaptures) - one each for GSM / GSM A-interface,
   GTP (GTPv1 or GTPv2), and S1AP or NGAP - and keep them in this folder.
2. Run the helper for each capture (tshark must be on the PATH):

       python analyze_capture.py gsm   <gsm capture>
       python analyze_capture.py gtp   <gtp capture>
       python analyze_capture.py s1ap  <s1ap capture>      (or ngap)

3. In the Wireshark GUI also use the display filters from the manual
   (`gsm_a.dtap`, `gsm_map`, `gtp`, `gtpv2`, `s1ap`, `ngap`) and
   **Statistics > Flow Graph** to draw the message sequence.
4. Copy the observed interface, procedure and ordered key messages into the
   Output table of the manual. Attach the screenshots and the protocol-stack
   drawings.

Typical answers to check yourself against
- GSM location update: Location Updating Request -> Authentication Request/Response
  -> Location Updating Accept (DTAP over BSSAP on the A interface).
- GTP: user IP packets are encapsulated in GTP-U on UDP port 2152; the TEID
  identifies the tunnel (one direction of one bearer) at the receiving end.
- S1AP: carried over SCTP; attach = Initial UE Message (Attach Request) ->
  Downlink NAS (Authentication/Security Mode) -> Initial Context Setup
  Request/Response -> Uplink NAS (Attach Complete).
