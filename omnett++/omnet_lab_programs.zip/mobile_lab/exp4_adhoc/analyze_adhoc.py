"""Experiment 4 - post-processing of AODV / DSDV results.

For every .sca file in results/AODV and results/DSDV it computes
   packet delivery ratio  PDR      = received / sent * 100
   average end-to-end delay        = sum(delay) / received       (ms)
   routing overhead                = control packets / data packets delivered
and prints the table of the manual (averaged over the repetitions).

Routing overhead needs the .pcap files written by omnetpp.ini and `tshark`
on the PATH (it ships with Wireshark).  Without them the column shows n/a.

Usage:  python analyze_adhoc.py [results_dir]        (default: results)
"""
import glob
import os
import re
import shutil
import subprocess
import sys
from collections import defaultdict

import warnings

import numpy as np

warnings.filterwarnings("ignore", category=RuntimeWarning)

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
from omnet_results import parse_sca

SRC = re.compile(r"\.host\[([0-3])\]\.app\[0\]$")
DST = re.compile(r"\.host\[(1[0-3])\]\.app\[0\]$")
DATA_PORT = 5000


def metrics(sent, received, delay_sum_s, control_pkts):
    pdr = 100.0 * received / sent
    delay_ms = 1000.0 * delay_sum_s / received
    overhead = control_pkts / received if control_pkts is not None else float("nan")
    return pdr, delay_ms, overhead


def control_packets(stem):
    """Transmitted IP frames that are NOT the UDP data flows = routing control."""
    pcaps = glob.glob(stem + "-host*.pcap")
    if not pcaps or not shutil.which("tshark"):
        return None
    total = 0
    for p in pcaps:
        out = subprocess.run(
            ["tshark", "-r", p, "-Y", "ip && !(udp.dstport==%d)" % DATA_PORT,
             "-T", "fields", "-e", "frame.number"],
            capture_output=True, text=True).stdout
        total += len([l for l in out.splitlines() if l.strip()])
    return total


def one_run(sca):
    r = parse_sca(sca)
    sent = sum(v for m, n, v in r["scalars"] if n == "packetSent:count" and SRC.search(m))
    recv = sum(v for m, n, v in r["scalars"] if n == "packetReceived:count" and DST.search(m))
    dsum = 0.0
    for (m, n), s in r["stats"].items():
        if n.startswith("endToEndDelay") and DST.search(m):
            dsum += s.get("mean", 0.0) * s.get("count", 0.0)
    speed = int(float(r["itervars"].get("maxSpeed", "0")))
    return speed, sent, recv, dsum, control_packets(sca[:-4])


def main():
    rdir = sys.argv[1] if len(sys.argv) > 1 else "results"
    table = defaultdict(list)
    for proto in ("AODV", "DSDV"):
        for sca in sorted(glob.glob(os.path.join(rdir, proto, "*.sca"))):
            speed, sent, recv, dsum, ctl = one_run(sca)
            if sent > 0 and recv > 0:
                table[(proto, speed)].append(metrics(sent, recv, dsum, ctl))
    if not table:
        sys.exit("No results found under %s/AODV and %s/DSDV." % (rdir, rdir))

    print("\n%-9s %-11s %-9s %-15s %-17s" % ("Protocol", "Speed(m/s)", "PDR (%)", "Avg delay (ms)", "Routing overhead"))
    print("-" * 65)
    with open("exp4_summary.csv", "w") as fh:
        fh.write("protocol,speed_mps,pdr_percent,avg_delay_ms,routing_overhead\n")
        for (proto, speed) in sorted(table, key=lambda k: (k[0], k[1])):
            a = np.array(table[(proto, speed)], dtype=float)
            pdr, dly, ovh = np.nanmean(a[:, 0]), np.nanmean(a[:, 1]), np.nanmean(a[:, 2])
            ovs = "n/a" if np.isnan(ovh) else "%.2f" % ovh
            print("%-9s %-11d %-9.1f %-15.1f %-17s" % (proto, speed, pdr, dly, ovs))
            fh.write("%s,%d,%.2f,%.2f,%s\n" % (proto, speed, pdr, dly, ovs))
    print("\nSaved exp4_summary.csv")


if __name__ == "__main__":
    main()
